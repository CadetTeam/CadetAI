"use client"

import { SignInButton, SignUpButton } from "@clerk/nextjs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useEffect, useState } from "react";

function ClerkAuthButtons() {
  return (
    <div className="space-x-4">
      <SignInButton mode="modal">
        <Button size="lg" className="bg-primary hover:bg-primary/90">
          Sign In
        </Button>
      </SignInButton>
      <SignUpButton mode="modal">
        <Button size="lg" variant="outline">
          Get Started
        </Button>
      </SignUpButton>
    </div>
  );
}

function FallbackAuthButtons() {
  return (
    <div className="space-x-4">
      <Button size="lg" className="bg-primary hover:bg-primary/90">
        Sign In
      </Button>
      <Button size="lg" variant="outline">
        Get Started
      </Button>
    </div>
  );
}

export default function Home() {
  const [hasClerkKey, setHasClerkKey] = useState(false);
  
  // Check if Clerk is available
  useEffect(() => {
    const clerkKey = process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY;
    setHasClerkKey(!!clerkKey && !clerkKey.includes('placeholder'));
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            CadetAI Platform
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            A secure, compliant platform delivering 6 modular &apos;apps&apos; aligned with government-mandated processes. 
            Designed for enterprise and government use with emphasis on collaboration, AI-driven automation, and dynamic visualizations.
          </p>
          {hasClerkKey ? <ClerkAuthButtons /> : <FallbackAuthButtons />}
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>AI-Driven APD Generation</CardTitle>
              <CardDescription>
                Automatically generate Advanced Planning Documents with AI assistance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Template-based generation for government standards like OMB A-130 with collaborative contributions and audited chats.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Real-Time Collaboration</CardTitle>
              <CardDescription>
                Work together seamlessly with real-time editing and conflict resolution
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Supabase real-time channels for edits, version control with e-signature integration.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Enterprise Security</CardTitle>
              <CardDescription>
                Built for government and enterprise compliance requirements
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                FedRAMP Moderate, SOC 2 Type II, GDPR/CCPA compliance with zero-trust security model.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
